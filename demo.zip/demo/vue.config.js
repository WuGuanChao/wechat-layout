// 配置生产环境或开发环境
const path = require('path')

const resolve = dir => path.join(__dirname, dir)
// 在node中，有全局变量process表示的是当前的node进程。process.env包含着关于系统环境的信息。
// 但是process.env中并不存在NODE_ENV这个东西。NODE_ENV是用户一个自定义的变量，在webpack中它的用途是判断生产环境或开发环境的依据的。
// 在此中，procution在生产环境和开发环境表示不同的值
const BASE_URL = process.env.NODE_ENV === 'procution' ? '/' : '/'

module.exports = {
  // eslint检测开关
  lintOnSave: false,
  // 部署生产环境和开发环境下的URL。
  // 默认情况下，Vue CLI 会假设你的应用是被部署在一个域名的根路径上。
  // 例如 https://www.my-app.com/。如果应用被部署在一个子路径上，你就需要用这个选项指定这个子路径。例如，如果你的应用被部署在 https://www.my-app.com/my-app/，则设置 baseUrl 为 /my-app/。
  baseUrl: BASE_URL,
  // 配置快速路径(第一个参数代替第二个参数的，意思就是说你在项目开发中引入路径，'@'就相当于path.join(__dirname, 'src'))
  chainWebpack: config => {
    config.resolve.alias
      .set('@', resolve('src'))
			.set('_v', resolve('src/views'))
      .set('_c', resolve('src/components'))
  },
  // 如果你不需要生产环境的 source map，可以将其设置为 false 以加速生产环境构建。
  //  打包之后发现map文件过大，项目文件体积很大，设置为false就可以不输出map文件
  //  map文件的作用在于：项目打包后，代码都是经过压缩加密的，如果运行时报错，输出的错误信息无法准确得知是哪里的代码报错。
  //  有了map就可以像未加密的代码一样，准确的输出是哪一行哪一列有错。
  productionSourceMap: false,
  // 跨域代理
  devServer: {
    // 使用axios原生的没有问题
    // 如果使用我封装的方法，需要把lib文件夹中的axios.文件中的getInstanseConfig方法里的config对象中的baseURL: this.baseUrl注释掉
    // 然后再此处填写接口地址即可；devServer会自动把proxy属性拼接上你填写的相对路径！！！然后跨域就没问题了
    // !!! 这种跨域方式只适用与开发环境。生成环境还是解开baseURL比较好
    // proxy: 'http://localhost:3000'
  }
}
