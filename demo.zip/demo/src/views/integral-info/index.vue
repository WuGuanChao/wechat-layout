<template>
	<div>
		<ul class="container">
			<li>
				<div>
					<span>2018-12-21 08:00</span>
					<span>会员直推</span>
				</div>
				<span class="count">+420</span>
			</li>
			<li>
				<div>
					<span>2018-12-21 08:00</span>
					<span>会员直推</span>
				</div>
				<span class="count">+420</span>
			</li>
			<li>
				<div>
					<span>2018-12-21 08:00</span>
					<span>会员直推</span>
				</div>
				<span class="count">+420</span>
			</li>
			<li>
				<div>
					<span>2018-12-21 08:00</span>
					<span>会员直推</span>
				</div>
				<span class="count">+420</span>
			</li>
			<li>
				<div>
					<span>2018-12-21 08:00</span>
					<span>会员直推</span>
				</div>
				<span class="count">+420</span>
			</li>
		</ul>
		<p class="no-more">没有更多了哦~</p>
	</div>
</template>

<script>
	export default {

	}
</script>

<style scoped="scoped" lang="less">
	.container {
		li {
			display: flex;
			justify-content: space-between;
			align-items: center;
			padding: .3rem;
			background: #fff;
			border-bottom: .01rem solid #F6F6F6;

			div:first-child {
				flex-direction: column;
				display: flex;

				span:first-child {
					font-size: 12px;
					color: #828282;
					margin-bottom: .1rem;
				}
			}

			.count {
				font-size: 18px;
				color: #F5A623;
			}
		}
	}
	
	.no-more {
		padding: .3rem;
		text-align: center;
		color: #9B9B9B;
	}
</style>
