<template>
	<div class="container">
		<div style="width: 100vw;height: .3rem;background: #F5F5F5;"></div>
		<div class="ipt-item">
			<label for="consignee-name">收货人</label>
			<input type="text" placeholder="请输入收货人姓名" id="consignee-name" />
		</div>
		<div class="ipt-item">
			<label for="consignee-name">联系电话</label>
			<input type="text" placeholder="请输入收货人联系电话" id="consignee-name" />
		</div>
		<div class="ipt-item">
			<label for="consignee-name">省市区</label>
			<input type="text" placeholder="请选择收货省市区" id="consignee-name" />
		</div>
		<div class="ipt-item">
			<label for="consignee-name">详细地址</label>
			<input type="text" placeholder="请输入收货详细地址" id="consignee-name" />
		</div>
		<div style="width: 100vw;height: .3rem;background: #F5F5F5;"></div>
		<div @click="changeDefaultAddress" class="default-adddress">
			<span>设为默认地址</span>
			<mt-switch v-model="defaultAddress">
			</mt-switch>
		</div>
	</div>
</template>

<script>
	export default {
		data() {
			return {
				defaultAddress: false
			}
		},
		methods: {
			// 更改默认地址
			changeDefaultAddress () {
				this.defaultAddress = !(this.defaultAddress)
			}
		}
	}
</script>

<style scoped="scoped" lang="less">
	.container {
		background: #fff;
	}
	.ipt-item {
		padding: .3rem;
		display: flex;
		align-items: center;
		border-bottom: .01rem solid #F6F6F6;
		label {
			width: 1.4rem;
		}
	}
	input::-webkit-input-placeholder {
		font-family: PingFangSC-Regular;
		font-size: 14px;
		color: #9B9B9B;
	}
	.default-adddress {
		padding: .18rem .3rem;
		display: flex;
		align-items: center;
		justify-content: space-between;
	}
</style>
