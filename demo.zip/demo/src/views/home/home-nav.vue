<template>
	<ul class="container">
		<li @click="goMyOrder">
			<img src="../../assets/icon/home-icon/dingdan.png" />
			<span>我的订单</span>
		</li>
		<li @click="goMyAddress">
			<img src="../../assets/icon/home-icon/address.png" />
			<span>我的地址</span>
		</li>
		<li @click="goMyTeam">
			<img src="../../assets/icon/home-icon/team.png" />
			<span>我的团队</span>
		</li>
		<li @click="goOfficialMsg">
			<img src="../../assets/icon/home-icon/platform.png" />
			<span>平台消息</span>
		</li>
	</ul>
</template>

<script>
	export default {
		data () {
			return {
				
			}
		},
		methods: {
			// 跳转到我的订单
			goMyOrder () {
				this.$router.push({
					name: 'order-index'
				})
			},
			// 跳转至平台消息
			goOfficialMsg () {
				this.$router.push({
					name: 'official-msg-index'
				})
			},
			// 跳转至我的团队
			goMyTeam () {
				this.$router.push({
					name: 'my-team-index'
				})
			},
			// 跳转到我的地址
			goMyAddress () {
				this.$router.push({
					name: 'my-address_index'
				})
			}
		}
	}
</script>

<style scoped="scoped"  lang="less">
.container {
	display: flex;
	align-items: center;
	width: 100vw;
	height: 2.4rem;
	background: #fff;
	li {
		width: 25%;
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
		color: #8E8E93;
		img {
			width: 1.1rem;
			margin-bottom: .2rem;
		}
	}
}
</style>
