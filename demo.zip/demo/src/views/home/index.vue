<template>
	<!-- 首页 -->
	<div>
		<search :title="searchTitle"></search>
		<slider></slider>
		<home-nav></home-nav>
		<div style="width: 100vw;height: 0;padding-bottom: .3rem;background: #f6f6f6"></div>
		<home-shop></home-shop>
	</div>
</template>

<script>
	import search from '_c/search'
	import slider from '_c/slider'
	import homeNav from '_v/home/home-nav.vue'
	import homeShop from '_v/home/home-shop.vue'
	export default {
		data () {
			return {
				searchTitle: '多功能垃圾回收箱'
			}
		},
		methods: {
			
		},
		components: {
			search, slider, homeNav, homeShop
		},
		created () {
			
		}
	}
</script>
<style lang='less' scoped>
	
</style>
