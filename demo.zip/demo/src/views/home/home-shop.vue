<template>
	<div class="container" @click="shopDetail">
		<img src="http://img0.imgtn.bdimg.com/it/u=1487805790,817321898&fm=26&gp=0.jpg" />
		<span class="shop-info">多功能垃圾回收箱</span>
		<p>
			<span>惊爆价：</span>
			<span><span>￥</span>1999</span>
		</p>
	</div>
</template>

<script>
	export default {
		data () {
			return {
				
			}
		},
		methods: {
			shopDetail () {
				this.$router.push({
					name: 'shop_detail_shop'
				})
			}
		}
	}
</script>

<style scoped="scoped" lang="less">
.container {
	padding: .3rem;
	background: #fff;
	img {
		width: 100%;
		margin-bottom: .34rem;
	}
	.shop-info {
		font-size: 18px;
		color: #4A4A4A;
	}
	p {
		margin-top: .2rem;
		
		span:first-child {
			color: #4A4A4A;
		}
		span:last-child {
			font-size: 18px;
			color: #D0021B;
			span {
				font-size: 14px;
			}
		}
	}
}
</style>
