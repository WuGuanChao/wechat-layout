<template>
	<!-- 商品详情 -->
	<div class="container">
		<slider></slider>
		<shop-info></shop-info>
		<div style="width: 100vw;height: .3rem;background: #F5F5F5;"></div>
		<shop-explain-detail></shop-explain-detail>
		<div style="width: 100vw;height: .3rem;background: #F5F5F5;"></div>
		<handle-rule></handle-rule>
		<div style="width: 100vw;height: .3rem;background: #F5F5F5;"></div>
		<add-shop-cart></add-shop-cart>
	</div>
</template>

<script>
	import slider from '_c/slider'
	import shopInfo from './shop-info.vue'
	import shopExplainDetail from './shop-explain-detail.vue'
	import handleRule from './handle-rule.vue'
	import addShopCart from './add-shop-cart.vue'
	export default {
		data () {
			return {
				
			}
		},
		components: {
			slider, shopInfo, shopExplainDetail, handleRule, addShopCart 
		}
	}
</script>

<style scoped="scoped" lang="less">
.container {
	
}
</style>
