<template>
	<!-- 商品详情介绍 -->
	<div class="container">
		<div class="container-main">
			富文本编辑器富文本编辑器富文本编辑器富文本编辑器富文本编辑器富文本编辑器富文本编辑器富文本编辑器富文本编辑器富
			文本编辑器富文本编辑器富文本编辑器富文本编辑器富文本编辑器富文本编辑器富文本编辑器富文本编辑器富文本编辑器富文本编辑器富文本编辑器富文本编辑器富文本编辑器富文本编辑器富
			文本编辑器富文本编辑器富文本编辑器富文本编辑器富文本编辑器
		</div>
	</div>
</template>

<script>
	export default {
		
	}
</script>

<style scoped="scoped" lang="less">
.container {
	background: #fff;
	padding: .3rem;
	font-size: 14px;
}
</style>
