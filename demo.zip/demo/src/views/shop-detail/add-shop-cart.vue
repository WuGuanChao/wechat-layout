<template>
	<div class="container">
		<div style="height: 1rem;"></div>
		<div class="container-main">
			<div>
				<img src="../../assets/icon/shop-icon/shop-car-icon.png" />
				<span>加入购物车</span>
			</div>
			<div @click="goShopBuy">立即购买</div>
		</div>
	</div>
</template>

<script>
	export default {
		data () {
			return {
				
			}
		},
		methods: {
			goShopBuy () {
				this.$router.push({
					name: 'shop_buy_index'
				})
			}
		}
	}
</script>

<style scoped="scoped" lang="less">
.container-main {
	width: 100vw;
	height: 1rem;
	position: fixed;
	bottom: 0;
	display: flex;
	justify-content: space-between;
	div {
		width: 50vw;
		height: 100%;
		display: flex;
		background: #fff;
		justify-content: center;
		align-items: center;
		font-size: 14px;
		img {
			width: .5rem;
			margin-right: .1rem;
		}
	}
	div:last-child {
		background-image: linear-gradient(-119deg, #3AB8FF 0%, #218BFB 100%);
		font-size: 14px;
		color: #FFFFFF;
	}
}
</style>
