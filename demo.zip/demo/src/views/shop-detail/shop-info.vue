<template>
	<div class="container">
		<p>多功能垃圾回收箱</p>
		<p><span>￥&nbsp;</span>1999.00</p>
	</div>
</template>

<script>
	export default {

	}
</script>

<style scoped="scoped" lang="less">
	.container {
		background: #fff !important;
		padding: .3rem;

		p:first-child {
			font-size: 14px;
			color: #4A4A4A;
			margin-bottom: .1rem;
		}

		p:last-child {
			font-size: 18px;
			color: #D0021B;

			span {
				font-size: 12px;
			}
		}
	}
</style>
