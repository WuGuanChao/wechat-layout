<template>
	<div class="container">
		<div class="container-title">
			<mt-checklist v-model="confirmRule" :options="['同意平台规则']">
			</mt-checklist>
		</div>
		<hr style="margin: 0 .3rem;" />
		<div class="container-content" v-if="showRuleFlag">
			<div class="container-content-main">
				富文本编辑器富文本编辑器富文本编辑器富文本编辑器富文本编辑器富文本编辑器富文本编辑器富文本编辑器富文本编辑器富
				文本编辑器富文本编辑器富文本编辑器富文本编辑器富文本编辑器富文本编辑器富文本编辑器富文本编辑器富文本编辑器富文本编辑器富文本编辑器富文本编辑器富文本编辑器富文本编辑器富
				文本编辑器富文本编辑器富文本编辑器富文本编辑器富文本编辑器
			</div>
		</div>
	</div>
</template>

<script>
	export default {
		data() {
			return {
				confirmRule: [
					{
						label: '同意平台规则',
						value: '1'
					}
				],
				showRuleFlag: false
			}
		},
		methods: {
			
		},
		watch: {
			confirmRule (newVal) {
				this.showRuleFlag = newVal[1] && true
			}
		},
		created() {

		}
	}
</script>

<style lang="less" scoped="scoped">
	.container {
		background: #fff;
	}
.container-title {
	display: flex;
	justify-content: center;
	align-items: center;
	color: #4A4A4A;
}
.container-content {
	padding: .3rem;
	font-size: 14px;
}
</style>
