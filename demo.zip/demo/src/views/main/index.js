import main from '@/views/main/main.vue'
export default main
