	<!-- 平台消息 -->
<template>
	<div class="container">
		<p>消息标题消息标题消息标题消</p>
		<img src="https://ss0.bdstatic.com/70cFvHSh_Q1YnxGkpoWK1HF6hhy/it/u=820403872,3992760726&fm=26&gp=0.jpg" />
		<div>大量内容大量内容大量内容大量内容大量内容大量内容大量内容大量内容大量内容大量内容大量内容大量内容
		大量内容大量内容大量内容大量内容大量内容大量内容大量内容大量内容大量内容大量内容大量内容大量内容大量内容大量内容
		大量内容大量内容大量内容大量内容大量内容大量内容大量内容大量内容大量内容大量内容大量内容大量内容大量内容大量内容
		大量内容大量内容大量内容大量内容大量内容大量内容大量内容大量内容大量内容大量内容大量内容大量内容大量内容大量内容大量内容
		大量内容大量内容大量内容大量内容大量内容大量内容大量内容大量内容大量内容大量内容大量内容大量内容
		大量内容大量内容大量内容大量内容大量内容大量内容大量内容大量内容大量内容大量内容大量内容大量内容大量内容大量内容
		大量内容大量内容大量内容大量内容大量内容大量内容大量内容大量内容大量内容大量内容大量内容大量内容大量内容大量内容
		大量内容大量内容大量内容大量内容大量内容大量内容大量内容大量内容大量内容大量内容大量内容大量内容大量内容大量内容大量内容
		</div>
	</div>
</template>

<script>
	export default {
		data () {
			return {
				
			}
		},
		methods: {
			
		},
	}
</script>

<style scoped="scoped" lang="less">
.container {
	padding: .3rem;
	height: 100vh;
	background: #fff;
	p {
		font-family: PingFangSC-Medium;
		padding: .3rem;
		padding-top: 0rem;
		text-align: center;
		font-size: .36rem;
		letter-spacing: 0.22px;
	}
	
	img {
		width: 100%;
		margin-bottom: .3rem;
	}
	
	div {
		line-height: .36rem;
		padding-bottom: .3rem;
	}
	
}
</style>
