<template>
	<!-- 我的 -->
	<div class="container">
		<my-header ></my-header>
		<div style="width: 100vw;height: .3rem;background: #F5F5F5;"></div>
		<my-order></my-order>
		<my-integral></my-integral>
		<my-options></my-options>
	</div>
</template>

<script>
	import myHeader from './my-header.vue'
	import myOrder from './my-order.vue'
	import myIntegral from './my-integral.vue'
	import myOptions from './my-option.vue'
	export default {
		data () {
			return {
				
			}
		},
		methods: {
			
		},
		components: {
			myHeader, myOrder, myIntegral, myOptions
		},
		created () {
			
		}
	}
</script>

<style scoped="scoped" lang="less">
.container {
	background: #fff;
}
</style>
