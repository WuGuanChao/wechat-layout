<template>
	<div>
		<ul class="container">
			<li class="arrow" @click="goMyAddress">
				<div>
					<img src="../../assets/icon/my-icon/dizhi.png" />
					<span>我的地址</span>
				</div>
			</li>
			<li @click="goMyTeam" class="arrow">
				<div>
					<img src="../../assets/icon/my-icon/team.png" />
					<span>我的团队</span>
				</div>
			</li>
			<li @click="goIntegralInfo" class="arrow">
				<div>
					<img src="../../assets/icon/my-icon/jilu.png" />
					<span>兑换记录</span>
				</div>
			</li>
			<li class="arrow">
				<div>
					<img src="../../assets/icon/my-icon/erweima.png" />
					<span>推广二维码</span>
				</div>
			</li>
			<li @click="goOfficialMsg" class="arrow">
				<div>
					<img src="../../assets/icon/my-icon/xiaoxi.png" />
					<span>平台消息</span>
				</div>
			</li>
		</ul>
		<div style="width: 100vw;height: .3rem;background: #F5F5F5;"></div>
	</div>
</template>

<script>
	export default {
		data () {
			return {
				
			}
		},
		methods: {
			// 跳转到我的地址
			goMyAddress () {
				this.$router.push({
					name: 'my-address_index'
				})
			},
			// 跳转至我的团队
			goMyTeam () {
				this.$router.push({
					name: 'my-team-index'
				})
			},
			// 跳转到兑换记录
			goIntegralInfo () {
				this.$router.push({
					name: 'exchange-record-index'
				})
			},
			// 跳转至平台消息
			goOfficialMsg () {
				this.$router.push({
					name: 'official-msg-index'
				})
			},
		}
	}
</script>

<style scoped="scoped" lang="less">
.container {
	display: flex;
	flex-direction: column;
	
	li {
		padding: 0 .3rem;
		height: .9rem;
		display: flex;
		align-items: center;
		border-bottom: .01rem solid #F6F6F6;
		font-size: 14px;
		color: #4A4A4A;
		img {
			width: .4rem;
			margin-right: .4rem;
		}
	}
	
}
</style>
