export default {
	title: '昱田'
}
