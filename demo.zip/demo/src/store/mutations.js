export default {
	setTitle (state, title) {
		state.title = title
	}
}
