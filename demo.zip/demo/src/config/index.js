// 配置对象
// console.log(process.env.NODE_ENV)
// 我现在在开发环境打印process.env.NODE_ENV结果为：development
// 我现在生成环境(线上)打印process.env.NODE_ENV结果为：production
export const baseURL =
  process.env.NODE_ENV === 'production'
    ? 'http://localhost:3000' // 生成环境接口地址
    : 'http://localhost:3000' // 开发环境接口地址
export const path = process.env.NODE_ENV
