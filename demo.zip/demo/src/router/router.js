export default [{
		path: '/',
		// 首页
		name: 'main_index',
		component: () => import('@/views/main/main.vue'),
		children: [
			{
				path: 'home',
				name: 'home_index',
				meta: {
					title: '昱田'
				},
				component: () => import('@/views/home')
			},
			{
				path: 'shop',
				name: 'shop_index',
				meta: {
					title: '购物车'
				},
				component: () => import('@/views/shop')
			},
			{
				path: 'my',
				name: 'my_index',
				meta: {
					title: '我的'
				},
				component: () => import('@/views/my')
			}
		]
	},
	{
		path: '/shop-detail',
		name: 'shop_detail_shop',
		meta: {
			title: '商品详情'
		},
		component: () => import('@/views/shop-detail')
	},
	{
		path: '/shop-buy',
		name: 'shop_buy_index',
		meta: {
			title: '商品购买'
		},
		component: () => import('@/views/shop-buy')
	},
	{
		path: '/my-address',
		name: 'my-address_index',
		meta: {
			title: '收货地址'
		},
		component: () => import('@/views/my-address')
	},
	{
		path: '/edit-address',
		name: 'edit_address_index',
		meta: {
			title: '编辑收货地址'
		},
		component: () => import('@/views/edit-address')
	},
	{
		path: '/edit-my-data',
		name: 'edit-my-data-index',
		meta: {
			title: '修改资料'
		},
		component: () => import('@/views/edit-my-data')
	},
	{
		path: '/order',
		name: 'order-index',
		meta: {
			title: '我的订单'
		},
		component: () => import('@/views/order')
	},
	{
		path: '/my-exchange',
		name: 'my-exchange-index',
		meta: {
			title: '兑换'
		},
		component: () => import('@/views/my-exchange')
	},
	{
		path: '/exchange-record',
		name: 'exchange-record-index',
		meta: {
			title: '兑换记录'
		},
		component: () => import('@/views/exchange-record')
	},
	{
		path: '/integral-info',
		name: 'integral-info-index',
		meta: {
			title: '积分明细'
		},
		component: () => import('@/views/integral-info')
	},
	{
		path: '/official-msg',
		name: 'official-msg-index',
		meta: {
			title: '平台消息'
		},
		component: () => import('@/views/official-msg')
	},
	{
		path: '/msg-detail',
		name: 'msg-detail-index',
		meta: {
			title: '详情'
		},
		component: () => import('@/views/msg-detail')
	},
	{
		path: '/my-team',
		name: 'my-team-index',
		meta: {
			title: '我的团队'
		},
		component: () => import('@/views/my-team')
	},
	{
		path: '/order-detail',
		name: 'order-detail-index',
		meta: {
			title: '订单详情'
		},
		component: () => import('@/views/order-detail')
	}
]
