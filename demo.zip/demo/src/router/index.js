import Vue from 'vue'
import Router from 'vue-router'
import routes from './router'
import store from '@/store'

Vue.use(Router)

const router = new Router({
  routes
})


//  const HAS_LOGINED = true
// // 导航守卫---路由跳转前置钩子 to(即将要进入的目标 路由对象) from(当前导航正要离开的路由) next(一个函数，如果你确定要跳转，需要执行这个next函数)
router.beforeEach((to, from, next) => {
  // 动态设置浏览器title标题
  to.meta && to.meta.title && to.meta.title && store.commit('setTitle', to.meta.title)
  // 此处写导航守卫
  
  
  next()
  
})


// 后置钩子
// router.afterEach((to, from) => {})

export default router
