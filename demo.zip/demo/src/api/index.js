import HttpRequst from '@/lib/axios'
const axios = new HttpRequst()
export default axios
