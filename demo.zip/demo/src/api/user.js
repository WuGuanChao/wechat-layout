import axios from './index'
export const getUserInfo = ({ name }) => {
  // 它会返回一个Promise成功或失败的结果
  return axios.request({
    url: '/post',
    data: {
      name
    }
  })
}
