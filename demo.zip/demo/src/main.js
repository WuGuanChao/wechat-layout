// import FastClick from 'fastclick'
// FastClick.attach(document.body);
import Vue from 'vue'
import App from './App.vue'
// 引入路由
import router from './router'
// 引入vuex
import store from './store'
// 引入Mint UI
import MintUI from 'mint-ui'
import 'mint-ui/lib/style.min.css'
import './assets/css/wechat-layout.css'
// 引入时间插件
import dayjs from 'dayjs'
import relativeTime from 'dayjs/plugin/relativeTime' // 引入相对时间
import 'dayjs/locale/zh-cn'

Vue.use(MintUI)
dayjs.locale('zh-cn') // 引入中文
dayjs.extend(relativeTime)

new Vue({
  router,
  store,
  render: h => h(App) // 将App组件挂载上去,还有第二个可选参数
}).$mount('#app')
