<template>
	<div>
		<div class="container">
			<div class="container-main">
				<img src="../../assets/icon/home-icon/home-search.png" />
				<input type="text" :placeholder="title" />
			</div>
		</div>
		<div style="margin-top: calc(1.02rem)"></div>
	</div>
</template>

<script>
	export default {
		data() {
			return {}
		},
		props: {
			title: {
				type: String,
				default: ''
			}
		},
		methods: {},

		components: {},

		computed: {},

		created() {}
	}
</script>
<style lang="less" scoped="scoped">
	.container {
		background: #fff;
		height: 1.02rem;
		display: flex;
		position: fixed;
		top: 40px;
		width: 100%;
		z-index: 9999;

		.container-main {
			margin-left: .3rem;
			margin-right: .3rem;
			flex: 1;
			display: flex;
			align-items: center;
			background: rgba(142, 142, 147, 0.12);
			height: .72rem;
			border-radius: 10px;

			img {
				width: .28rem;
				height: .28rem;
				margin-left: .16rem;
				margin-right: .2rem;
			}
		}
	}
</style>
