import slider from './slider.vue'
export default slider
